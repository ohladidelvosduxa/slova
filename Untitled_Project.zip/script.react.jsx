import React, { useState } from 'react';

function App() {
  // Состояние для отслеживания текущего экрана
  const [currentScreen, setCurrentScreen] = useState('main');
  
  // 10 разных фонов для экранов
  const backgrounds = {
    main: '#F5F5DC', // Молочный
    screen1: '#FFB6C1', // Розовый
    screen2: '#ADD8E6', // Голубой
    screen3: '#90EE90', // Зеленый
    screen4: '#FFFFE0', // Желтый
    screen5: '#D8BFD8', // Фиолетовый
    screen6: '#FFDAB9', // Персиковый
    screen7: '#B0E0E6', // Пудровый
    screen8: '#F0FFF0', // Медовый
    screen9: '#F0F8FF', // Небесный
    screen10: '#FAEBD7', // Слонячий
  };
  
  // 10 разных надписей
  const screens = [
    "Приключения", "Путешествия", "Открытия", 
    "Исследования", "Тайны", "Секреты", 
    "Чудеса", "Волшебство", "Фантазии", "Мечты"
  ];
  
  // Стили контейнера
  const containerStyle = {
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    backgroundColor: backgrounds[currentScreen],
    transition: 'background-color 0.5s ease',
    position: 'relative',
    overflow: 'hidden',
  };
  
  // Стили для надписей на главном экране
  const mainTextStyle = {
    position: 'absolute',
    fontSize: '24px',
    fontWeight: 'bold',
    cursor: 'pointer',
    padding: '10px',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: '5px',
    transition: 'transform 0.3s ease',
  };
  
  // Стили для возврата на главный экран
  const returnButtonStyle = {
    position: 'absolute',
    top: '20px',
    left: '20px',
    padding: '10px 20px',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  };
  
  // Позиции для 10 надписей на главном экране
  const positions = [
    { top: '10%', left: '10%' },
    { top: '10%', left: '30%' },
    { top: '10%', left: '50%' },
    { top: '10%', left: '70%' },
    { top: '30%', left: '10%' },
    { top: '30%', left: '30%' },
    { top: '30%', left: '50%' },
    { top: '30%', left: '70%' },
    { top: '50%', left: '10%' },
    { top: '50%', left: '30%' },
  ];
  
  return (
    <div style={containerStyle}>
      {/* Кнопка возврата на главный экран (показывается не на главном экране) */}
      {currentScreen !== 'main' && (
        <button 
          style={returnButtonStyle}
          onClick={() => setCurrentScreen('main')}
        >
          На главную
        </button>
      )}
      
      {/* Отображаем надписи только на главном экране */}
      {currentScreen === 'main' && screens.map((text, index) => (
        <div
          key={index}
          style={{
            ...mainTextStyle,
            top: positions[index].top,
            left: positions[index].left,
          }}
          onClick={() => setCurrentScreen(`screen${index + 1}`)}
          onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
          onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
        >
          {text}
        </div>
      ))}
    </div>
  );
}

export default App;